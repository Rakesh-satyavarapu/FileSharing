require("dotenv").config();
const express = require("express");
const cors = require("cors");
const dns = require("dns");

const app = express();
const port = process.env.PORT || 3000;

// ------------------- Custom Logger -------------------
const logs = [];
const logger = (req, res, next) => {
  logs.push({
    method: req.method,
    url: req.originalUrl,
    body: req.body,
    timestamp: new Date().toISOString(),
  });
  next();
};

// ------------------- App Setup -------------------
app.use(cors());
app.use(express.json());
app.use(logger);

// ------------------- In-memory DB -------------------
const urlDatabase = {}; // { shortcode: { url, expiry } }

// ------------------- Helpers -------------------
const isValidUrl = (url) => {
  try {
    const urlObj = new URL(url);
    return ["http:", "https:"].includes(urlObj.protocol);
  } catch {
    return false;
  }
};

const generateShortcode = () =>
  Math.random().toString(36).substring(2, 8); // 6-char code

// ------------------- API Endpoints -------------------

// Create Short URL
app.post("/shorturls", (req, res) => {
  const { url, validity, shortcode } = req.body;

  if (!url || !isValidUrl(url)) {
    return res.status(400).json({ error: "Invalid URL" });
  }

  const hostname = new URL(url).hostname;
  dns.lookup(hostname, (err) => {
    if (err) return res.status(400).json({ error: "Invalid hostname" });

    let code = shortcode || generateShortcode();

    if (!/^[a-zA-Z0-9]{4,20}$/.test(code)) {
      return res
        .status(400)
        .json({ error: "Shortcode must be 4–20 alphanumeric characters" });
    }

    if (urlDatabase[code]) {
      return res.status(409).json({ error: "Shortcode already exists" });
    }

    const ttl = validity && Number.isInteger(validity) ? validity : 30;
    const expiry = Date.now() + ttl * 60 * 1000;

    urlDatabase[code] = { url, expiry };

    res.status(201).json({
      short_url: `http://localhost:${port}/${code}`,
      original_url: url,
      validity: ttl,
    });
  });
});

// Redirect
app.get("/:code", (req, res) => {
  const entry = urlDatabase[req.params.code];
  if (!entry) return res.status(404).json({ error: "Shortcode not found" });

  if (Date.now() > entry.expiry) {
    delete urlDatabase[req.params.code];
    return res.status(410).json({ error: "Short URL expired" });
  }

  res.redirect(entry.url);
});

// Logs (for verification)
app.get("/logs", (req, res) => res.json(logs));

// ------------------- Start Server -------------------
app.listen(port, () => {
  logs.push({ message: `Running on port ${port}`, time: new Date().toISOString() });
});
